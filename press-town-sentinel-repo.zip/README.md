# The Press-Town Sentinel

**Liberty, Law, and Public Accountability for the Heartland**

The Press-Town Sentinel is an independent, civic-accountability investigative reporting platform and public records repository built with Flask. It features an editorial dispatch desk, public records/FOIA investigation tracking, and a zero-knowledge confidential whistleblower intake portal.

---

## Project Structure

```text
press-town-sentinel/
├── app.py                      # Core Flask web server & intake logic
├── requirements.txt            # Python dependencies
├── .gitignore                  # Git ignore rules for Python/Flask
├── static/
│   └── style.css               # Heartland Watchdog editorial styling
├── templates/
│   ├── base.html               # Main layout & navigation
│   ├── index.html              # Dispatches & editorial briefings
│   ├── investigations.html     # Active FOIA / audit case files
│   ├── submit_tip.html         # Whistleblower desk intake form with OpSec notice
│   └── tip_success.html        # Cryptographic receipt token display
└── standalone/
    └── index.html              # Complete, zero-dependency single-file preview
```

---

## Quickstart & Local Setup

### 1. Clone & Enter Repository
```bash
git clone https://github.com/<your-username>/press-town-sentinel.git
cd press-town-sentinel
```

### 2. Set Up Virtual Environment & Dependencies
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Run the Development Server
```bash
python3 app.py
```
Open your browser at `http://127.0.0.1:5000`.

---

## Features
- **Editorial Dispatches Desk**: Front-page investigative summaries with metadata tags.
- **Investigative Dockets**: FOIA register categorized across local government, municipal spending, zoning, and civil liberties.
- **Confidential Whistleblower Portal**: Built-in operational security guidelines and receipt tokens generated using standard library crypto-primitives (`secrets.token_hex`).
- **Heartland Watchdog Theme**: Clean typography and civic-minded color palette (Deep Navy, Crimson, Gold, Parchment).
