from flask import Flask, render_template, request, redirect, url_for, flash
import datetime
import secrets

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sentinel-secure-heartland-key-2026'

# Mock storage for confidential submissions
CONFIDENTIAL_TIPS = []

@app.context_processor
def inject_common_context():
    return {
        'current_year': datetime.datetime.now().year,
        'tagline': "Liberty, Law, and Public Accountability for the Heartland"
    }

@app.route('/')
def home():
    featured_articles = [
        {
            "id": 1,
            "title": "County Drainage Board Approves Undisclosed Easements",
            "category": "Land Rights",
            "date": "Oct 10, 2026",
            "summary": "Internal county documents show expedited approvals for commercial drainage easements without public zoning hearing notices."
        },
        {
            "id": 2,
            "title": "Municipal Budget Audit: Discrepancies in Heavy Fleet Procurement",
            "category": "Taxpayer Accountability",
            "date": "Oct 04, 2026",
            "summary": "A closer look at municipal spending contracts reveals unexplained cost overruns across three consecutive fiscal quarters."
        }
    ]
    return render_template('index.html', articles=featured_articles)

@app.route('/investigations')
def investigations():
    categories = [
        {"name": "Local Government Transparency", "count": 4},
        {"name": "Public Infrastructure & Spending", "count": 6},
        {"name": "Agricultural & Environmental Compliance", "count": 3},
        {"name": "Civil Liberties & Due Process", "count": 2}
    ]
    return render_template('investigations.html', categories=categories)

@app.route('/tip-desk', methods=['GET', 'POST'])
def submit_tip():
    if request.method == 'POST':
        subject = request.form.get('subject', '').strip()
        category = request.form.get('category', '').strip()
        details = request.form.get('details', '').strip()
        contact_method = request.form.get('contact_method', 'Anonymous')

        if not subject or not details:
            flash("Please complete all required fields before submitting.", "error")
            return redirect(url_for('submit_tip'))

        token = secrets.token_hex(6).upper()

        CONFIDENTIAL_TIPS.append({
            "token": token,
            "subject": subject,
            "category": category,
            "details": details,
            "contact_method": contact_method,
            "timestamp": datetime.datetime.utcnow().isoformat()
        })

        return render_template('tip_success.html', token=token)

    return render_template('submit_tip.html')

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
